package com.banking.bankingapp;

/**
 * Represents a bank account with account number, account type, open date, balance, and customer ID.
 */
public class Account {
    private long accountNumber; // 7 digits
    private String openDate; // Format: MM-DD-YYYY
    private float balance;
    private int customerId; // 5 digits

    /**
     * Constructor to initialize an Account object.
     *
     * @param accountNumber The account number (7 digits).
     * @param openDate      The open date in MM-DD-YY format.
     * @param balance       The initial account balance.
     * @param customerId    The customer ID (5 digits).
     */
    public Account(long accountNumber, String openDate, float balance, int customerId) {
        this.accountNumber = accountNumber;
        this.openDate = openDate;
        this.balance = balance;
        this.customerId = customerId;
    }

    /**
     * Deposits a specified amount into the account.
     *
     * @param amount The amount to deposit.
     */
    public void deposit(float amount) {
        this.balance += amount;
    }

    /**
     * Withdraws a specified amount from the account, if sufficient balance is available.
     *
     * @param amount The amount to withdraw.
     */
    public void withdraw(float amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
        }
    }

    /**
     * Gets the account number.
     *
     * @return The account number.
     */
    public long getAccountNumber() {
        return accountNumber;
    }


    /**
     * Gets the open date of the account.
     *
     * @return The open date in MM-DD-YY format.
     */
    public String getOpenDate() {
        return openDate;
    }

    /**
     * Gets the current balance of the account.
     *
     * @return The account balance.
     */
    public float getBalance() {
        return balance;
    }



    /**
     * Gets the customer ID associated with the account.
     *
     * @return The customer ID (5 digits).
     */
    public int getCustomerId() {
        return customerId;
    }

}
