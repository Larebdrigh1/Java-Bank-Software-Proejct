package com.banking.bankingapp;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * This class represents the main graphical user interface (GUI) for the Banking Application.
 */
public class BankingAppGUI extends Application {

    private BankingApplication bankingApplication = new BankingApplication();
    private int loginAttempts = 0;

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        primaryStage.setTitle("Banking Application");

        // Load the logo
        FileInputStream input = new FileInputStream("src/main/resources/bank.png");
        Image image = new Image(input, 250, 250, false, true);
        ImageView imageView = new ImageView(image);

        // Customer ID and PIN Fields
        TextField customerIdField = new TextField();
        PasswordField pinField = new PasswordField();
        customerIdField.setMaxWidth(100);
        pinField.setMaxWidth(100);

        HBox fieldsBox = new HBox(10,
                new Label("Customer ID: "), customerIdField,
                new Label("PIN: "), pinField);
        fieldsBox.setAlignment(Pos.CENTER);

        // Login Button
        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> handleLogin(customerIdField, pinField, primaryStage));

        // Sign Up Button
        Button signUpButton = new Button("Sign Up");
        signUpButton.setOnAction(e -> openSignUpWindow());

        HBox buttonsBox = new HBox(10, loginButton, signUpButton);
        buttonsBox.setAlignment(Pos.CENTER);

        // Layout
        VBox layout = new VBox(10, imageView, fieldsBox, buttonsBox);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        // Scene
        Scene scene = new Scene(layout, 480, 480);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Handles the login process when the "Login" button is clicked.
     *
     * @param customerIdField The TextField for entering the customer ID.
     * @param pinField        The PasswordField for entering the PIN.
     * @param loginStage      The login Stage to be closed upon successful login.
     */
    private void handleLogin(TextField customerIdField, PasswordField pinField, Stage loginStage) {
        try {
            int customerId = Integer.parseInt(customerIdField.getText());
            int pin = Integer.parseInt(pinField.getText());

            if (bankingApplication.login(customerId, pin)) {
                loginStage.close(); // Close login window
                openMainMenuWindow(); // Open main menu window
            } else {
                loginAttempts++;
                if (loginAttempts >= 3) {
                    showAlert("Login Failed", "Too many failed login attempts. Exiting.");
                    Platform.exit(); // Terminate the application
                } else {
                    showAlert("Login Failed", "Incorrect ID or PIN. Attempts remaining: " + (3 - loginAttempts));
                }
            }
        } catch (NumberFormatException ex) {
            showAlert("Input Error", "Please enter valid numbers.");
        }
    }

    /**
     * Opens a new window for the signup process.
     * This window includes form fields for entering ID, name, email, phone number, address, and PIN.
     * Each field is arranged in a vertical layout with labels.
     */
    private void openSignUpWindow() {
        Stage signUpStage = new Stage();
        signUpStage.setTitle("Sign Up");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label idLabel = new Label("ID:");
        TextField idField = new TextField();
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        Label phoneLabel = new Label("Phone:");
        TextField phoneField = new TextField();
        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();
        Label pinLabel = new Label("PIN:");
        PasswordField pinField = new PasswordField();

        grid.add(idLabel, 0, 0);
        grid.add(idField, 1, 0);
        grid.add(nameLabel, 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(emailLabel, 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(phoneLabel, 0, 3);
        grid.add(phoneField, 1, 3);
        grid.add(addressLabel, 0, 4);
        grid.add(addressField, 1, 4);
        grid.add(pinLabel, 0, 5);
        grid.add(pinField, 1, 5);

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> handleSignUp(idField, nameField, emailField, phoneField, addressField, pinField, signUpStage));
        grid.add(submitButton, 0, 6, 2, 1);
        GridPane.setHalignment(submitButton, HPos.CENTER);

        Scene scene = new Scene(grid, 300, 300);
        signUpStage.setScene(scene);
        signUpStage.show();
    }


    /**
     * Handles the signup process when the submit button is clicked.
     * It collects the data from the form fields, validates them, and then attempts to sign up
     * the new customer using the banking application's signup method. If successful, it closes the signup window.
     * If the ID or PIN are not valid integers, it displays an error alert.
     *
     * @param idField The text field for the customer's ID.
     * @param nameField The text field for the customer's name.
     * @param emailField The text field for the customer's email.
     * @param phoneField The text field for the customer's phone number.
     * @param addressField The text field for the customer's address.
     * @param pinField The password field for the customer's PIN.
     * @param signUpStage The stage (window) of the signup form, which will be closed upon successful signup.
     */
    private void handleSignUp(TextField idField, TextField nameField, TextField emailField, TextField phoneField, TextField addressField, PasswordField pinField, Stage signUpStage) {
        String name = nameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String address = addressField.getText();
        int pin;
        int id;
        try {
            id = Integer.parseInt(idField.getText());
            pin = Integer.parseInt(pinField.getText());
            String response = bankingApplication.signup(id, pin, name, email, phone, address);
            showAlert("Sign Up", response);
            signUpStage.close();
        } catch (NumberFormatException ex) {
            showAlert("Error", "ID/PIN must be a number.");
        }
    }


    /**
     * Opens the main menu window with various banking options.
     */
    private void openMainMenuWindow() {
        Stage mainMenuStage = new Stage();
        mainMenuStage.setTitle("Banking System - Main Menu");

        // Welcome Text
        Label welcomeLabel = new Label("Welcome to the Bank");
        welcomeLabel.setStyle("-fx-font-size: 24px;"); // Set the font size

        // Buttons
        Button depositButton = new Button("Deposit Funds");
        depositButton.setMinWidth(160);
        depositButton.setMinHeight(80);
        depositButton.setStyle("-fx-background-color: #0e868f; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");


        Button withdrawButton = new Button("Withdraw Funds");
        withdrawButton.setMinWidth(160);
        withdrawButton.setMinHeight(80);
        withdrawButton.setStyle("-fx-background-color: #43de5a; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");


        Button transferButton = new Button("Transfer Funds");
        transferButton.setMinWidth(160);
        transferButton.setMinHeight(80);
        transferButton.setStyle("-fx-background-color: #493ad6; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");


        Button balanceButton = new Button("Display Balance");
        balanceButton.setMinWidth(160);
        balanceButton.setMinHeight(80);
        balanceButton.setStyle("-fx-background-color: #d6853a; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");


        Button quitButton = new Button("Quit");
        quitButton.setMinWidth(160);
        quitButton.setMinHeight(80);
        quitButton.setStyle("-fx-background-color: #b51d2c; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");


        // Button actions
        depositButton.setOnAction(e -> openDepositWindow());
        withdrawButton.setOnAction(e -> openWithdrawWindow());
        transferButton.setOnAction(e -> openTransferFundsWindow());
        balanceButton.setOnAction(e -> openDisplayBalanceWindow());
        quitButton.setOnAction(e -> Platform.exit());

        // Button Layouts
        HBox firstRowButtons = new HBox(20, depositButton, withdrawButton);
        firstRowButtons.setAlignment(Pos.CENTER);
        HBox secondRowButtons = new HBox(20, transferButton, balanceButton);
        secondRowButtons.setAlignment(Pos.CENTER);

        // Main Layout
        VBox layout = new VBox(20, welcomeLabel, firstRowButtons, secondRowButtons, quitButton);
        layout.setAlignment(Pos.CENTER);

        // Scene
        Scene scene = new Scene(layout, 480, 480);
        mainMenuStage.setScene(scene);
        mainMenuStage.show();
    }

    /**
     * Opens the window for depositing funds into an account.
     */
    private void openDepositWindow() {
        Stage depositStage = new Stage();
        depositStage.setTitle("Deposit Funds");

        // Account Number Field and Label
        Label accountNumberLabel = new Label("Account Number:");
        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("Account Number");
        HBox accountNumberBox = new HBox(10, accountNumberLabel, accountNumberField);
        accountNumberBox.setAlignment(Pos.CENTER_LEFT);

        // Amount Field and Label
        Label amountLabel = new Label("              Amount:");
        TextField amountField = new TextField();
        amountField.setPromptText("Amount");
        HBox amountBox = new HBox(10, amountLabel, amountField);
        amountBox.setAlignment(Pos.CENTER_LEFT);

        // Deposit Button and Receipt Area
        Button depositButton = new Button("Deposit");
        depositButton.setStyle("-fx-background-color: #0e868f; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");
        TextArea receiptArea = new TextArea();
        receiptArea.setPadding(new Insets(10, 10, 10, 10)); // Adding 10px padding
        receiptArea.setEditable(false);

        depositButton.setOnAction(e -> {
            try {
                long accountNumber = Long.parseLong(accountNumberField.getText());
                float amount = Float.parseFloat(amountField.getText());
                String receipt = bankingApplication.deposit(accountNumber, amount);
                receiptArea.setText(receipt);
            } catch (NumberFormatException ex) {
                showAlert("Error", "Invalid input. Please enter valid numbers.");
            }
        });

        VBox layout = new VBox(10, accountNumberBox, amountBox, depositButton, receiptArea);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 300, 300);
        depositStage.setScene(scene);
        depositStage.show();
    }


    /**
     * Opens the window for withdrawing funds from an account.
     */
    private void openWithdrawWindow() {
        Stage withdrawStage = new Stage();
        withdrawStage.setTitle("Withdraw Funds");

        // Account Number Field and Label
        Label accountNumberLabel = new Label("Account Number:");
        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("Account Number");
        HBox accountNumberBox = new HBox(10, accountNumberLabel, accountNumberField);
        accountNumberBox.setAlignment(Pos.CENTER_LEFT);

        // Amount Field and Label
        Label amountLabel = new Label("              Amount:");
        TextField amountField = new TextField();
        amountField.setPromptText("Amount");
        HBox amountBox = new HBox(10, amountLabel, amountField);
        amountBox.setAlignment(Pos.CENTER_LEFT);

        // Withdraw Button and Receipt Area
        Button withdrawButton = new Button("Withdraw");
        withdrawButton.setStyle("-fx-background-color: #43de5a; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");
        TextArea receiptArea = new TextArea();
        receiptArea.setPadding(new Insets(10, 10, 10, 10)); // Adding 10px padding
        receiptArea.setEditable(false);

        withdrawButton.setOnAction(e -> {
            try {
                long accountNumber = Long.parseLong(accountNumberField.getText());
                float amount = Float.parseFloat(amountField.getText());
                String receipt = bankingApplication.withdraw(accountNumber, amount);
                receiptArea.setText(receipt);
            } catch (NumberFormatException ex) {
                showAlert("Error", "Invalid input. Please enter valid numbers.");
            } catch (Exception ex) {
                showAlert("Error", ex.getMessage());
            }
        });

        VBox layout = new VBox(10, accountNumberBox, amountBox, withdrawButton, receiptArea);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 300, 300);
        withdrawStage.setScene(scene);
        withdrawStage.show();
    }

    /**
     * Opens the window for transferring funds between accounts.
     */
    private void openTransferFundsWindow() {
        Stage transferStage = new Stage();
        transferStage.setTitle("Transfer Funds");

        // From Account Number
        Label fromAccountLabel = new Label("    From Account Number:");
        TextField fromAccountField = new TextField();
        fromAccountField.setPromptText("From Account Number");
        HBox fromAccountBox = new HBox(10, fromAccountLabel, fromAccountField);
        fromAccountBox.setAlignment(Pos.CENTER_LEFT);

        // To Account Number
        Label toAccountLabel = new Label("        To Account Number:");
        TextField toAccountField = new TextField();
        toAccountField.setPromptText("To Account Number");
        HBox toAccountBox = new HBox(10, toAccountLabel, toAccountField);
        toAccountBox.setAlignment(Pos.CENTER_LEFT);

        // Amount
        Label amountLabel = new Label("\t\t\t   Amount:");
        TextField amountField = new TextField();
        amountField.setPromptText("Amount");
        HBox amountBox = new HBox(10, amountLabel, amountField);
        amountBox.setAlignment(Pos.CENTER_LEFT);

        // Transfer Button and Receipt Area
        Button transferButton = new Button("Transfer");
        transferButton.setStyle("-fx-background-color: #493ad6; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");
        TextArea receiptArea = new TextArea();
        receiptArea.setPadding(new Insets(10, 10, 10, 10));
        receiptArea.setEditable(false);

        transferButton.setOnAction(e -> {
            try {
                long fromAccount = Long.parseLong(fromAccountField.getText());
                long toAccount = Long.parseLong(toAccountField.getText());
                float amount = Float.parseFloat(amountField.getText());
                String result = bankingApplication.transfer(fromAccount, toAccount, amount);
                receiptArea.setText(result);
            } catch (NumberFormatException ex) {
                showAlert("Error", "Invalid input. Please enter valid numbers.");
            } catch (Exception ex) {
                showAlert("Error", ex.getMessage());
            }
        });

        // Layout
        VBox layout = new VBox(10, fromAccountBox, toAccountBox, amountBox, transferButton, receiptArea);
        layout.setAlignment(Pos.CENTER);

        // Scene
        Scene scene = new Scene(layout, 350, 400);
        transferStage.setScene(scene);
        transferStage.show();
    }


    /**
     * Opens the window for displaying the account balance.
     */
    private void openDisplayBalanceWindow() {
        Stage balanceStage = new Stage();
        balanceStage.setTitle("Display Balance");

        Label accountNumberLabel = new Label("Account Number:");
        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("Account Number");

        Button displayBalanceButton = new Button("Display Balance");
        displayBalanceButton.setStyle("-fx-background-color: #d6853a; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 16px;");

        TextArea balanceArea = new TextArea();
        balanceArea.setPadding(new Insets(10, 10, 10, 10));
        balanceArea.setEditable(false);

        displayBalanceButton.setOnAction(e -> {
            try {
                long accountNumber = Long.parseLong(accountNumberField.getText());
                String balance = bankingApplication.displayBalance(accountNumber);
                balanceArea.setText(balance);
            } catch (NumberFormatException ex) {
                showAlert("Error", "Invalid input. Please enter a valid account number.");
            } catch (Exception ex) {
                showAlert("Error", ex.getMessage());
            }
        });

        VBox layout = new VBox(10, accountNumberLabel, accountNumberField, displayBalanceButton, balanceArea);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 300, 200);
        balanceStage.setScene(scene);
        balanceStage.show();
    }

    /**
     * Displays an alert dialog with the specified title and message.
     *
     * @param title   The title of the alert dialog.
     * @param message The message to be displayed in the alert dialog.
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
