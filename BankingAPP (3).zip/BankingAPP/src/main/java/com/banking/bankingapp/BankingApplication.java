package com.banking.bankingapp;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Represents a banking application that manages customer accounts and transactions.
 */
public class BankingApplication {
    private List<Customer> customers;
    private List<Account> accounts;
    private FileHandler fileHandler;
    private int loggedInCustomerId = -1; // ID of the logged-in customer

    /**
     * Constructor to create a BankingApplication object and load initial customer and account data.
     */
    public BankingApplication() {
        fileHandler = new FileHandler();
        loadInitialData();
    }

    /**
     * Load initial customer and account data from files.
     */
    private void loadInitialData() {
        customers = fileHandler.readCustomersFromFile("src/main/resources/customers.txt");
        accounts = fileHandler.readAccountsFromFile("src/main/resources/accounts.txt");
    }

    /**
     * Attempts to log in a customer with the provided customer ID and PIN.
     *
     * @param customerId The customer ID to log in.
     * @param pin        The PIN associated with the customer.
     * @return True if the login is successful, false otherwise.
     */
    public boolean login(int customerId, int pin) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId && customer.getCustomerPIN() == pin) {
                loggedInCustomerId = customerId; // Store the logged-in customer ID
                return true; // Login successful
            }
        }
        return false; // Login failed
    }

    /**
     * Signs up a new customer with the provided details and writes their data to the customers file.
     *
     * @param customerId The customer's ID.
     * @param customerPIN The customer's PIN.
     * @param name The customer's name.
     * @param email The customer's email.
     * @param phone The customer's phone number.
     * @param address The customer's address.
     * @return A success message if the signup is successful.
     */
    public String signup(int customerId, int customerPIN, String name, String email, String phone, String address) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId) {
                return "Error: A customer with this ID already exists.";
            }
        }

        Customer newCustomer = new Customer(customerId, customerPIN, name, email, phone, address);
        customers.add(newCustomer);
        fileHandler.writeCustomerToFile(newCustomer, "src/main/resources/customers.txt");

        long accountNumber = generateUniqueAccountNumber();
        Account newAccount = new Account(accountNumber, getCurrentDate(), 0.0f, customerId);
        accounts.add(newAccount);
        fileHandler.writeAccountsToFile(accounts, "src/main/resources/accounts.txt");

        return "Signup successful. Welcome, " + name + "! An account has been created for you.";
    }


    /**
     * Finds an account in the list of accounts by its account number.
     *
     * @param accountNumber The account number to search for.
     * @return The Account object with the specified account number, or null if not found.
     */
    private Account findAccountByNumber(long accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    /**
     * Deposits a specified amount into the given account and records the transaction.
     *
     * @param accountNumber The account number to deposit into.
     * @param amount        The amount to deposit.
     * @return A receipt or an error message indicating the result of the deposit.
     */
    String deposit(long accountNumber, float amount) {
        Account account = findAccountByNumber(accountNumber);
        if (account != null) {
            if (account.getCustomerId() != loggedInCustomerId) {
                return "Error: You can only deposit into your own accounts.";
            }
            account.deposit(amount);
            Transaction transaction = recordTransaction(account.getCustomerId(), accountNumber, 'D', amount);
            fileHandler.writeAccountsToFile(accounts, "src/main/resources/accounts.txt");
            return generateReceipt(transaction);
        } else {
            return "Account not found.";
        }
    }


    /**
     * Withdraws a specified amount from the given account and records the transaction.
     *
     * @param accountNumber The account number to withdraw from.
     * @param amount        The amount to withdraw.
     * @return A receipt or an error message indicating the result of the withdrawal.
     */
    String withdraw(long accountNumber, float amount) {
        Account account = findAccountByNumber(accountNumber);
        if (account != null) {
            if (account.getCustomerId() != loggedInCustomerId) {
                return "Error: You can only withdraw from your own accounts.";
            }
            if (account.getBalance() >= amount) {
                account.withdraw(amount);
                Transaction transaction = recordTransaction(account.getCustomerId(), accountNumber, 'W', amount);
                fileHandler.writeAccountsToFile(accounts, "src/main/resources/accounts.txt");
                return generateReceipt(transaction);
            } else {
                return "Insufficient balance.";
            }
        } else {
            return "Account not found.";
        }
    }


    /**
     * Displays the balance of the given account.
     *
     * @param accountNumber The account number to check the balance for.
     * @return A string containing the account balance or an error message if the account is not found.
     */
    String displayBalance(long accountNumber) {
        Account account = findAccountByNumber(accountNumber);
        if (account != null) {
            if (account.getCustomerId() != loggedInCustomerId) {
                return "Error: You can only check the balance of your own accounts.";
            }
            return "Account Balance: $" + account.getBalance();
        } else {
            return "Account not found.";
        }
    }



    /**
     * Transfers a specified amount from one account to another and records the transaction.
     *
     * @param fromAccountNumber The account number to transfer from.
     * @param toAccountNumber   The account number to transfer to.
     * @param amount            The amount to transfer.
     * @return A receipt or an error message indicating the result of the transfer.
     */
    String transfer(long fromAccountNumber, long toAccountNumber, float amount) {
        Account fromAccount = findAccountByNumber(fromAccountNumber);
        Account toAccount = findAccountByNumber(toAccountNumber);

        if (fromAccount != null && toAccount != null) {
            if (fromAccount.getCustomerId() != loggedInCustomerId) {
                return "Error: You can only transfer from your own accounts.";
            }

            if (fromAccount.getBalance() >= amount) {
                fromAccount.withdraw(amount);
                toAccount.deposit(amount);
                Transaction transaction = recordTransaction(loggedInCustomerId, fromAccountNumber, 'T', amount);
                fileHandler.writeAccountsToFile(accounts, "src/main/resources/accounts.txt");
                return generateReceipt(transaction);
            } else {
                return "Insufficient balance for transfer.";
            }
        } else {
            return "One or both accounts not found.";
        }
    }

    /**
     * Records a transaction and writes it to a file.
     *
     * @param customerNumber   The customer number associated with the transaction.
     * @param accountNumber    The account number associated with the transaction.
     * @param transactionType  The transaction type ('D' for Deposit, 'W' for Withdrawal, 'T' for Transfer).
     * @param amount           The transaction amount.
     * @return The Transaction object representing the recorded transaction.
     */
    private Transaction recordTransaction(int customerNumber, long accountNumber, char transactionType, float amount) {
        Transaction transaction = new Transaction(customerNumber, accountNumber, transactionType, amount);
        fileHandler.writeTransactionToFile(transaction, "src/main/resources/transactions.txt");
        return transaction;
    }

    /**
     * Generates a receipt for a transaction, including bank and customer information.
     *
     * @param transaction The Transaction object for which to generate the receipt.
     * @return A formatted receipt as a string.
     */
    private String generateReceipt(Transaction transaction) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

        Customer customer = null;
        for (Customer c : customers) {
            if (c.getCustomerId() == transaction.getCustomerNumber()) {
                customer = c;
                break;
            }
        }

        if (customer == null) {
            return "Customer not found.";
        }

        return "Bank Name: My - Bank\n" +
                "Bank Address: 123 Street, ABC\n" +
                "Customer Name: " + customer.getName() + "\n" +
                "Customer Address: " + customer.getAddress() + "\n" +
                "Account Number: " + transaction.getAccountNumber() + "\n" +
                "Transaction Amount: $" + transaction.getTransactionAmount() + "\n" +
                "Transaction Type: " + (transaction.getTransactionType() == 'D' ? "Deposit" : "Withdrawal") + "\n" +
                "Transaction Date and Time: " + formatter.format(transaction.getTransactionDate());
    }

    /**
     * Generates a unique 7-digit account number.
     * This method generates a random number between 1000000 and 9999999 and checks if it already exists.
     * If the generated number exists, it attempts to generate a new number until a unique number is found.
     *
     * @return A unique 7-digit long account number.
     */
    private long generateUniqueAccountNumber() {
        long accountNumber;
        do {
            accountNumber = (long) (Math.random() * 9000000) + 1000000;
        } while (accountNumberExists(accountNumber));
        return accountNumber;
    }

    /**
     * Checks if an account number already exists in the list of accounts.
     * This method iterates through the list of accounts and compares the input account number with each account's number.
     *
     * @param accountNumber The account number to check for existence.
     * @return true if the account number exists, false otherwise.
     */
    private boolean accountNumberExists(long accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets the current date in the format "MM-dd-yyyy".
     * This method uses {@link SimpleDateFormat} to format the current date.
     *
     * @return A string representing the current date in the format "MM-dd-yyyy".
     */
    private String getCurrentDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
        return formatter.format(new Date());
    }

}

