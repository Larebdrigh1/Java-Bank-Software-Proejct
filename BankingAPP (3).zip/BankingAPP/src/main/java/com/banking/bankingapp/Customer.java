package com.banking.bankingapp;

/**
 * Represents a bank customer with customer ID, PIN, name, email, phone, and address.
 */
public class Customer {
    private int customerId; // 5 digits
    private int customerPIN; // 4 digits
    private String name;
    private String email;
    private String phone;
    private String address;

    /**
     * Constructor to initialize a Customer object.
     *
     * @param customerId   The customer ID (5 digits).
     * @param customerPIN  The customer PIN (4 digits).
     * @param name         The customer's name.
     * @param email        The customer's email address.
     * @param phone        The customer's phone number.
     * @param address      The customer's address.
     */
    public Customer(int customerId, int customerPIN, String name, String email, String phone, String address) {
        this.customerId = customerId;
        this.customerPIN = customerPIN;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    /**
     * Gets the customer ID.
     *
     * @return The customer ID (5 digits).
     */
    public int getCustomerId() {
        return customerId;
    }


    /**
     * Gets the customer PIN.
     *
     * @return The customer PIN (4 digits).
     */
    public int getCustomerPIN() {
        return customerPIN;
    }


    /**
     * Gets the customer's name.
     *
     * @return The customer's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the customer's address.
     *
     * @return The customer's address.
     */
    public String getAddress() {
        return address;
    }

    /**
     * Retrieves the email address.
     *
     * @return The email address as a String.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Retrieves the phone number.
     *
     * @return The phone number as a String.
     */
    public String getPhone() {
        return phone;
    }

}
