package com.banking.bankingapp;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles reading and writing customer, account, and transaction data to/from files.
 */
public class FileHandler {

    /**
     * Reads customer data from a file and returns a list of Customer objects.
     *
     * @param filename The name of the file to read from.
     * @return A list of Customer objects.
     */
    public List<Customer> readCustomersFromFile(String filename) {
        List<Customer> customers = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                Customer customer = new Customer(
                        Integer.parseInt(data[0]), // customerId
                        Integer.parseInt(data[1]), // customerPIN
                        data[2], // name
                        data[3], // email
                        data[4], // phone
                        data[5]  // address
                );
                customers.add(customer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return customers;
    }

    /**
     * Appends a customer's data to the customers file.
     *
     * @param customer The Customer object to append to the file.
     * @param filename The name of the file to append to.
     */
    public void writeCustomerToFile(Customer customer, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            String line = customer.getCustomerId() + "," +
                    customer.getCustomerPIN() + "," +
                    customer.getName() + "," +
                    customer.getEmail() + "," +
                    customer.getPhone() + "," +
                    customer.getAddress();
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads account data from a file and returns a list of Account objects.
     *
     * @param filename The name of the file to read from.
     * @return A list of Account objects.
     */
    public List<Account> readAccountsFromFile(String filename) {
        List<Account> accounts = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                Account account = new Account(
                        Long.parseLong(data[0]), // accountNumber
                        data[1], // openDate
                        Float.parseFloat(data[2]), // balance
                        Integer.parseInt(data[3])  // customerId
                );
                accounts.add(account);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return accounts;
    }

    /**
     * Writes account data to a file.
     *
     * @param accounts The list of Account objects to write to the file.
     * @param filename The name of the file to write to.
     */
    public void writeAccountsToFile(List<Account> accounts, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Account account : accounts) {
                String line = account.getAccountNumber() + "," +
                        account.getOpenDate() + "," +
                        account.getBalance() + "," +
                        account.getCustomerId();
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Writes a transaction to a file.
     *
     * @param transaction The Transaction object to write to the file.
     * @param filename    The name of the file to write to.
     */
    public void writeTransactionToFile(Transaction transaction, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(transaction.toString());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
