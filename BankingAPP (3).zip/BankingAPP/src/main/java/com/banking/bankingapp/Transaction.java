package com.banking.bankingapp;


import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Represents a bank transaction with a unique transaction number, customer number, account number,
 * transaction type (withdrawal or deposit), transaction date, and transaction amount.
 */
public class Transaction {
    private static int transactionCount = 0; // Static counter for unique transaction numbers
    private int transactionNumber;
    private int customerNumber; // 5 digits
    private long accountNumber; // 7 digits
    private char transactionType; // 'W' for Withdrawal, 'D' for Deposit
    private Date transactionDate;
    private float transactionAmount;

    /**
     * Constructor to create a new Transaction object.
     *
     * @param customerNumber   The customer number associated with the transaction (5 digits).
     * @param accountNumber    The account number associated with the transaction (7 digits).
     * @param transactionType  The transaction type ('W' for Withdrawal, 'D' for Deposit).
     * @param transactionAmount The transaction amount.
     */
    public Transaction(int customerNumber, long accountNumber, char transactionType, float transactionAmount) {
        this.transactionNumber = ++transactionCount; // Auto-increment transaction number
        this.customerNumber = customerNumber;
        this.accountNumber = accountNumber;
        this.transactionType = transactionType;
        this.transactionDate = new Date(); // Current date and time
        this.transactionAmount = transactionAmount;
    }

    /**
     * Converts the Transaction object to a string representation.
     *
     * @return A string representation of the transaction.
     */
    @Override
    public String toString() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        return transactionNumber + "," + customerNumber + "," + accountNumber + "," +
                transactionType + "," + transactionAmount + "," + formatter.format(transactionDate);
    }

    /**
     * Gets the current transaction count (number of transactions).
     *
     * @return The current transaction count.
     */
    public static int getTransactionCount() {
        return transactionCount;
    }

    /**
     * Gets the transaction number.
     *
     * @return The transaction number.
     */
    public int getTransactionNumber() {
        return transactionNumber;
    }

    /**
     * Gets the customer number associated with the transaction.
     *
     * @return The customer number (5 digits).
     */
    public int getCustomerNumber() {
        return customerNumber;
    }

    /**
     * Gets the account number associated with the transaction.
     *
     * @return The account number (7 digits).
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * Gets the transaction type ('W' for Withdrawal, 'D' for Deposit).
     *
     * @return The transaction type.
     */
    public char getTransactionType() {
        return transactionType;
    }

    /**
     * Gets the date and time of the transaction.
     *
     * @return The transaction date and time.
     */
    public Date getTransactionDate() {
        return transactionDate;
    }

    /**
     * Gets the transaction amount.
     *
     * @return The transaction amount.
     */
    public float getTransactionAmount() {
        return transactionAmount;
    }
}
