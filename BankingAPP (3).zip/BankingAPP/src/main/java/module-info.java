module com.banking.bankingapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.banking.bankingapp to javafx.fxml;
    exports com.banking.bankingapp;
}